```python
## importion pandas
import pandas as pd
```


```python
## chargement du fichier
df = pd.read_csv("C:/Users/User/Desktop/Ticanalyse/dataframe.csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>63.7.128.189</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>123.113.132.220</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>176.201.107.197</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>228.89.147.64</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>249.124.28.234</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>20.9.246.185</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>159.49.7.20</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 9 columns</p>
</div>




```python
## affichier les 5 preimier entre parathèse tu peut mettre le nombre voulus
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>63.7.128.189</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>123.113.132.220</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>176.201.107.197</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
  </tbody>
</table>
</div>




```python
## pour aficier les 5 derniers
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>228.89.147.64</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>249.124.28.234</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>20.9.246.185</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>159.49.7.20</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[20:50]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>Burnaby</td>
      <td>Pound</td>
      <td>bpoundk@twitpic.com</td>
      <td>Male</td>
      <td>242.33.177.243</td>
      <td>Ukraine</td>
      <td>50258</td>
      <td>1984</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>Fair</td>
      <td>Batho</td>
      <td>fbathol@theglobeandmail.com</td>
      <td>Male</td>
      <td>179.234.85.255</td>
      <td>China</td>
      <td>10285</td>
      <td>1298</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>Irv</td>
      <td>Borless</td>
      <td>iborlessm@blogtalkradio.com</td>
      <td>Male</td>
      <td>226.75.128.49</td>
      <td>Russia</td>
      <td>94803</td>
      <td>785</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>Aubrette</td>
      <td>Alsop</td>
      <td>aalsopn@devhub.com</td>
      <td>Female</td>
      <td>19.93.81.156</td>
      <td>Russia</td>
      <td>60528</td>
      <td>203</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>Reed</td>
      <td>Covotti</td>
      <td>rcovottio@discovery.com</td>
      <td>Bigender</td>
      <td>190.70.234.166</td>
      <td>Russia</td>
      <td>11289</td>
      <td>155</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>Bronson</td>
      <td>Campbell-Dunlop</td>
      <td>bcampbelldunlopp@mtv.com</td>
      <td>Male</td>
      <td>61.20.119.228</td>
      <td>Indonesia</td>
      <td>96965</td>
      <td>1096</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>Olenka</td>
      <td>Moyler</td>
      <td>omoylerq@mapquest.com</td>
      <td>Female</td>
      <td>127.140.59.170</td>
      <td>South Africa</td>
      <td>70070</td>
      <td>1740</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>Cullie</td>
      <td>Hun</td>
      <td>chunr@uol.com.br</td>
      <td>Male</td>
      <td>72.224.176.128</td>
      <td>Philippines</td>
      <td>95234</td>
      <td>837</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>Zorana</td>
      <td>Cosham</td>
      <td>zcoshams@posterous.com</td>
      <td>Female</td>
      <td>15.84.44.149</td>
      <td>Poland</td>
      <td>9013</td>
      <td>983</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>Luisa</td>
      <td>Jillett</td>
      <td>ljillettt@umn.edu</td>
      <td>Female</td>
      <td>38.142.210.59</td>
      <td>Argentina</td>
      <td>38566</td>
      <td>1014</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31</td>
      <td>Vassili</td>
      <td>Wilhelmy</td>
      <td>vwilhelmyu@salon.com</td>
      <td>Male</td>
      <td>1.74.109.191</td>
      <td>Indonesia</td>
      <td>35810</td>
      <td>1288</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>Noby</td>
      <td>Kiessel</td>
      <td>nkiesselv@booking.com</td>
      <td>Male</td>
      <td>251.171.126.177</td>
      <td>Macedonia</td>
      <td>40928</td>
      <td>319</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>Benjamin</td>
      <td>Cristofvao</td>
      <td>bcristofvaow@mapy.cz</td>
      <td>Male</td>
      <td>127.90.199.104</td>
      <td>Colombia</td>
      <td>7196</td>
      <td>818</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>Lance</td>
      <td>Whayman</td>
      <td>lwhaymanx@wufoo.com</td>
      <td>Male</td>
      <td>17.138.139.26</td>
      <td>Philippines</td>
      <td>81244</td>
      <td>948</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>Alberto</td>
      <td>Sibly</td>
      <td>asiblyy@prnewswire.com</td>
      <td>Male</td>
      <td>74.100.153.49</td>
      <td>China</td>
      <td>58550</td>
      <td>416</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>Candida</td>
      <td>Le Sarr</td>
      <td>clesarrz@java.com</td>
      <td>Female</td>
      <td>21.250.134.34</td>
      <td>China</td>
      <td>5485</td>
      <td>1001</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>Angeline</td>
      <td>Hardson</td>
      <td>ahardson10@adobe.com</td>
      <td>Female</td>
      <td>23.157.211.119</td>
      <td>Armenia</td>
      <td>72310</td>
      <td>560</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>Danny</td>
      <td>Cardall</td>
      <td>dcardall11@tiny.cc</td>
      <td>Male</td>
      <td>20.246.168.138</td>
      <td>Indonesia</td>
      <td>87558</td>
      <td>211</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>Velvet</td>
      <td>Jertz</td>
      <td>vjertz12@redcross.org</td>
      <td>Female</td>
      <td>6.50.20.63</td>
      <td>Argentina</td>
      <td>28800</td>
      <td>1323</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>Blancha</td>
      <td>Rayer</td>
      <td>brayer13@alibaba.com</td>
      <td>Female</td>
      <td>79.201.140.57</td>
      <td>Morocco</td>
      <td>42363</td>
      <td>1076</td>
    </tr>
    <tr>
      <th>40</th>
      <td>41</td>
      <td>Yance</td>
      <td>Pentercost</td>
      <td>ypentercost14@wix.com</td>
      <td>Male</td>
      <td>156.204.95.141</td>
      <td>Sweden</td>
      <td>80241</td>
      <td>814</td>
    </tr>
    <tr>
      <th>41</th>
      <td>42</td>
      <td>Cello</td>
      <td>Frigot</td>
      <td>cfrigot15@ebay.com</td>
      <td>Male</td>
      <td>2.58.177.31</td>
      <td>Indonesia</td>
      <td>18329</td>
      <td>470</td>
    </tr>
    <tr>
      <th>42</th>
      <td>43</td>
      <td>Riannon</td>
      <td>Casarino</td>
      <td>rcasarino16@opera.com</td>
      <td>Female</td>
      <td>209.17.132.89</td>
      <td>China</td>
      <td>50373</td>
      <td>1752</td>
    </tr>
    <tr>
      <th>43</th>
      <td>44</td>
      <td>Gerianne</td>
      <td>Bedding</td>
      <td>gbedding17@jigsy.com</td>
      <td>Female</td>
      <td>188.238.182.28</td>
      <td>Brazil</td>
      <td>64226</td>
      <td>434</td>
    </tr>
    <tr>
      <th>44</th>
      <td>45</td>
      <td>Starla</td>
      <td>Shoulder</td>
      <td>sshoulder18@msu.edu</td>
      <td>Female</td>
      <td>185.171.113.68</td>
      <td>Uzbekistan</td>
      <td>53804</td>
      <td>1308</td>
    </tr>
    <tr>
      <th>45</th>
      <td>46</td>
      <td>Marysa</td>
      <td>Remmer</td>
      <td>mremmer19@va.gov</td>
      <td>Female</td>
      <td>20.224.2.74</td>
      <td>China</td>
      <td>55371</td>
      <td>1902</td>
    </tr>
    <tr>
      <th>46</th>
      <td>47</td>
      <td>Israel</td>
      <td>Reavell</td>
      <td>ireavell1a@indiatimes.com</td>
      <td>Male</td>
      <td>188.11.149.81</td>
      <td>United States</td>
      <td>48761</td>
      <td>1827</td>
    </tr>
    <tr>
      <th>47</th>
      <td>48</td>
      <td>Odelle</td>
      <td>Spadoni</td>
      <td>ospadoni1b@ucoz.ru</td>
      <td>Female</td>
      <td>219.126.100.24</td>
      <td>China</td>
      <td>21505</td>
      <td>1963</td>
    </tr>
    <tr>
      <th>48</th>
      <td>49</td>
      <td>Cort</td>
      <td>Vibert</td>
      <td>cvibert1c@networkadvertising.org</td>
      <td>Male</td>
      <td>225.236.240.55</td>
      <td>Croatia</td>
      <td>83081</td>
      <td>685</td>
    </tr>
    <tr>
      <th>49</th>
      <td>50</td>
      <td>Freddie</td>
      <td>Goldsbrough</td>
      <td>fgoldsbrough1d@nbcnews.com</td>
      <td>Female</td>
      <td>188.244.180.32</td>
      <td>China</td>
      <td>21732</td>
      <td>1276</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.loc[20:50]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>Burnaby</td>
      <td>Pound</td>
      <td>bpoundk@twitpic.com</td>
      <td>Male</td>
      <td>242.33.177.243</td>
      <td>Ukraine</td>
      <td>50258</td>
      <td>1984</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>Fair</td>
      <td>Batho</td>
      <td>fbathol@theglobeandmail.com</td>
      <td>Male</td>
      <td>179.234.85.255</td>
      <td>China</td>
      <td>10285</td>
      <td>1298</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>Irv</td>
      <td>Borless</td>
      <td>iborlessm@blogtalkradio.com</td>
      <td>Male</td>
      <td>226.75.128.49</td>
      <td>Russia</td>
      <td>94803</td>
      <td>785</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>Aubrette</td>
      <td>Alsop</td>
      <td>aalsopn@devhub.com</td>
      <td>Female</td>
      <td>19.93.81.156</td>
      <td>Russia</td>
      <td>60528</td>
      <td>203</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>Reed</td>
      <td>Covotti</td>
      <td>rcovottio@discovery.com</td>
      <td>Bigender</td>
      <td>190.70.234.166</td>
      <td>Russia</td>
      <td>11289</td>
      <td>155</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>Bronson</td>
      <td>Campbell-Dunlop</td>
      <td>bcampbelldunlopp@mtv.com</td>
      <td>Male</td>
      <td>61.20.119.228</td>
      <td>Indonesia</td>
      <td>96965</td>
      <td>1096</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>Olenka</td>
      <td>Moyler</td>
      <td>omoylerq@mapquest.com</td>
      <td>Female</td>
      <td>127.140.59.170</td>
      <td>South Africa</td>
      <td>70070</td>
      <td>1740</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>Cullie</td>
      <td>Hun</td>
      <td>chunr@uol.com.br</td>
      <td>Male</td>
      <td>72.224.176.128</td>
      <td>Philippines</td>
      <td>95234</td>
      <td>837</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>Zorana</td>
      <td>Cosham</td>
      <td>zcoshams@posterous.com</td>
      <td>Female</td>
      <td>15.84.44.149</td>
      <td>Poland</td>
      <td>9013</td>
      <td>983</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>Luisa</td>
      <td>Jillett</td>
      <td>ljillettt@umn.edu</td>
      <td>Female</td>
      <td>38.142.210.59</td>
      <td>Argentina</td>
      <td>38566</td>
      <td>1014</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31</td>
      <td>Vassili</td>
      <td>Wilhelmy</td>
      <td>vwilhelmyu@salon.com</td>
      <td>Male</td>
      <td>1.74.109.191</td>
      <td>Indonesia</td>
      <td>35810</td>
      <td>1288</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>Noby</td>
      <td>Kiessel</td>
      <td>nkiesselv@booking.com</td>
      <td>Male</td>
      <td>251.171.126.177</td>
      <td>Macedonia</td>
      <td>40928</td>
      <td>319</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>Benjamin</td>
      <td>Cristofvao</td>
      <td>bcristofvaow@mapy.cz</td>
      <td>Male</td>
      <td>127.90.199.104</td>
      <td>Colombia</td>
      <td>7196</td>
      <td>818</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>Lance</td>
      <td>Whayman</td>
      <td>lwhaymanx@wufoo.com</td>
      <td>Male</td>
      <td>17.138.139.26</td>
      <td>Philippines</td>
      <td>81244</td>
      <td>948</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>Alberto</td>
      <td>Sibly</td>
      <td>asiblyy@prnewswire.com</td>
      <td>Male</td>
      <td>74.100.153.49</td>
      <td>China</td>
      <td>58550</td>
      <td>416</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>Candida</td>
      <td>Le Sarr</td>
      <td>clesarrz@java.com</td>
      <td>Female</td>
      <td>21.250.134.34</td>
      <td>China</td>
      <td>5485</td>
      <td>1001</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>Angeline</td>
      <td>Hardson</td>
      <td>ahardson10@adobe.com</td>
      <td>Female</td>
      <td>23.157.211.119</td>
      <td>Armenia</td>
      <td>72310</td>
      <td>560</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>Danny</td>
      <td>Cardall</td>
      <td>dcardall11@tiny.cc</td>
      <td>Male</td>
      <td>20.246.168.138</td>
      <td>Indonesia</td>
      <td>87558</td>
      <td>211</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>Velvet</td>
      <td>Jertz</td>
      <td>vjertz12@redcross.org</td>
      <td>Female</td>
      <td>6.50.20.63</td>
      <td>Argentina</td>
      <td>28800</td>
      <td>1323</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>Blancha</td>
      <td>Rayer</td>
      <td>brayer13@alibaba.com</td>
      <td>Female</td>
      <td>79.201.140.57</td>
      <td>Morocco</td>
      <td>42363</td>
      <td>1076</td>
    </tr>
    <tr>
      <th>40</th>
      <td>41</td>
      <td>Yance</td>
      <td>Pentercost</td>
      <td>ypentercost14@wix.com</td>
      <td>Male</td>
      <td>156.204.95.141</td>
      <td>Sweden</td>
      <td>80241</td>
      <td>814</td>
    </tr>
    <tr>
      <th>41</th>
      <td>42</td>
      <td>Cello</td>
      <td>Frigot</td>
      <td>cfrigot15@ebay.com</td>
      <td>Male</td>
      <td>2.58.177.31</td>
      <td>Indonesia</td>
      <td>18329</td>
      <td>470</td>
    </tr>
    <tr>
      <th>42</th>
      <td>43</td>
      <td>Riannon</td>
      <td>Casarino</td>
      <td>rcasarino16@opera.com</td>
      <td>Female</td>
      <td>209.17.132.89</td>
      <td>China</td>
      <td>50373</td>
      <td>1752</td>
    </tr>
    <tr>
      <th>43</th>
      <td>44</td>
      <td>Gerianne</td>
      <td>Bedding</td>
      <td>gbedding17@jigsy.com</td>
      <td>Female</td>
      <td>188.238.182.28</td>
      <td>Brazil</td>
      <td>64226</td>
      <td>434</td>
    </tr>
    <tr>
      <th>44</th>
      <td>45</td>
      <td>Starla</td>
      <td>Shoulder</td>
      <td>sshoulder18@msu.edu</td>
      <td>Female</td>
      <td>185.171.113.68</td>
      <td>Uzbekistan</td>
      <td>53804</td>
      <td>1308</td>
    </tr>
    <tr>
      <th>45</th>
      <td>46</td>
      <td>Marysa</td>
      <td>Remmer</td>
      <td>mremmer19@va.gov</td>
      <td>Female</td>
      <td>20.224.2.74</td>
      <td>China</td>
      <td>55371</td>
      <td>1902</td>
    </tr>
    <tr>
      <th>46</th>
      <td>47</td>
      <td>Israel</td>
      <td>Reavell</td>
      <td>ireavell1a@indiatimes.com</td>
      <td>Male</td>
      <td>188.11.149.81</td>
      <td>United States</td>
      <td>48761</td>
      <td>1827</td>
    </tr>
    <tr>
      <th>47</th>
      <td>48</td>
      <td>Odelle</td>
      <td>Spadoni</td>
      <td>ospadoni1b@ucoz.ru</td>
      <td>Female</td>
      <td>219.126.100.24</td>
      <td>China</td>
      <td>21505</td>
      <td>1963</td>
    </tr>
    <tr>
      <th>48</th>
      <td>49</td>
      <td>Cort</td>
      <td>Vibert</td>
      <td>cvibert1c@networkadvertising.org</td>
      <td>Male</td>
      <td>225.236.240.55</td>
      <td>Croatia</td>
      <td>83081</td>
      <td>685</td>
    </tr>
    <tr>
      <th>49</th>
      <td>50</td>
      <td>Freddie</td>
      <td>Goldsbrough</td>
      <td>fgoldsbrough1d@nbcnews.com</td>
      <td>Female</td>
      <td>188.244.180.32</td>
      <td>China</td>
      <td>21732</td>
      <td>1276</td>
    </tr>
    <tr>
      <th>50</th>
      <td>51</td>
      <td>Dody</td>
      <td>Wetter</td>
      <td>dwetter1e@squarespace.com</td>
      <td>Female</td>
      <td>56.168.213.151</td>
      <td>Argentina</td>
      <td>29366</td>
      <td>312</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (1000, 9)




```python
## pour recuper les colones 
df.columns
```




    Index(['id', 'first_name', 'last_name', 'email', 'gender', 'ip_address',
           'country', 'price', 'tax'],
          dtype='object')




```python
## pour les aligner ou le ranger on utilise toliste
df.columns.tolist()
```




    ['id',
     'first_name',
     'last_name',
     'email',
     'gender',
     'ip_address',
     'country',
     'price',
     'tax']




```python
df.index
```




    RangeIndex(start=0, stop=1000, step=1)




```python
## pour modifier l'index
df.set_index("email")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
    <tr>
      <th>email</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>rmcswan0@cargocollective.com</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>twyne1@walmart.com</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>lyurkiewicz2@xrea.com</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>Female</td>
      <td>63.7.128.189</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>tfri3@angelfire.com</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>Genderfluid</td>
      <td>123.113.132.220</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>dlappine4@fc2.com</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>Female</td>
      <td>176.201.107.197</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>ggoffern@amazon.de</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>Male</td>
      <td>228.89.147.64</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>hbosworthro@weebly.com</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>kfearnerp@behance.net</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>Male</td>
      <td>249.124.28.234</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>lbeswickrq@topsy.com</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>Female</td>
      <td>20.9.246.185</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>ajacsonrr@vistaprint.com</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>Male</td>
      <td>159.49.7.20</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 8 columns</p>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>63.7.128.189</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>123.113.132.220</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>176.201.107.197</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>228.89.147.64</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>249.124.28.234</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>20.9.246.185</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>159.49.7.20</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 9 columns</p>
</div>




```python
##df.set_index("email", inplace = True)
```


```python
df.index
```




    RangeIndex(start=0, stop=1000, step=1)




```python
df.index.tolist()
```




    [0,
     1,
     2,
     3,
     4,
     5,
     6,
     7,
     8,
     9,
     10,
     11,
     12,
     13,
     14,
     15,
     16,
     17,
     18,
     19,
     20,
     21,
     22,
     23,
     24,
     25,
     26,
     27,
     28,
     29,
     30,
     31,
     32,
     33,
     34,
     35,
     36,
     37,
     38,
     39,
     40,
     41,
     42,
     43,
     44,
     45,
     46,
     47,
     48,
     49,
     50,
     51,
     52,
     53,
     54,
     55,
     56,
     57,
     58,
     59,
     60,
     61,
     62,
     63,
     64,
     65,
     66,
     67,
     68,
     69,
     70,
     71,
     72,
     73,
     74,
     75,
     76,
     77,
     78,
     79,
     80,
     81,
     82,
     83,
     84,
     85,
     86,
     87,
     88,
     89,
     90,
     91,
     92,
     93,
     94,
     95,
     96,
     97,
     98,
     99,
     100,
     101,
     102,
     103,
     104,
     105,
     106,
     107,
     108,
     109,
     110,
     111,
     112,
     113,
     114,
     115,
     116,
     117,
     118,
     119,
     120,
     121,
     122,
     123,
     124,
     125,
     126,
     127,
     128,
     129,
     130,
     131,
     132,
     133,
     134,
     135,
     136,
     137,
     138,
     139,
     140,
     141,
     142,
     143,
     144,
     145,
     146,
     147,
     148,
     149,
     150,
     151,
     152,
     153,
     154,
     155,
     156,
     157,
     158,
     159,
     160,
     161,
     162,
     163,
     164,
     165,
     166,
     167,
     168,
     169,
     170,
     171,
     172,
     173,
     174,
     175,
     176,
     177,
     178,
     179,
     180,
     181,
     182,
     183,
     184,
     185,
     186,
     187,
     188,
     189,
     190,
     191,
     192,
     193,
     194,
     195,
     196,
     197,
     198,
     199,
     200,
     201,
     202,
     203,
     204,
     205,
     206,
     207,
     208,
     209,
     210,
     211,
     212,
     213,
     214,
     215,
     216,
     217,
     218,
     219,
     220,
     221,
     222,
     223,
     224,
     225,
     226,
     227,
     228,
     229,
     230,
     231,
     232,
     233,
     234,
     235,
     236,
     237,
     238,
     239,
     240,
     241,
     242,
     243,
     244,
     245,
     246,
     247,
     248,
     249,
     250,
     251,
     252,
     253,
     254,
     255,
     256,
     257,
     258,
     259,
     260,
     261,
     262,
     263,
     264,
     265,
     266,
     267,
     268,
     269,
     270,
     271,
     272,
     273,
     274,
     275,
     276,
     277,
     278,
     279,
     280,
     281,
     282,
     283,
     284,
     285,
     286,
     287,
     288,
     289,
     290,
     291,
     292,
     293,
     294,
     295,
     296,
     297,
     298,
     299,
     300,
     301,
     302,
     303,
     304,
     305,
     306,
     307,
     308,
     309,
     310,
     311,
     312,
     313,
     314,
     315,
     316,
     317,
     318,
     319,
     320,
     321,
     322,
     323,
     324,
     325,
     326,
     327,
     328,
     329,
     330,
     331,
     332,
     333,
     334,
     335,
     336,
     337,
     338,
     339,
     340,
     341,
     342,
     343,
     344,
     345,
     346,
     347,
     348,
     349,
     350,
     351,
     352,
     353,
     354,
     355,
     356,
     357,
     358,
     359,
     360,
     361,
     362,
     363,
     364,
     365,
     366,
     367,
     368,
     369,
     370,
     371,
     372,
     373,
     374,
     375,
     376,
     377,
     378,
     379,
     380,
     381,
     382,
     383,
     384,
     385,
     386,
     387,
     388,
     389,
     390,
     391,
     392,
     393,
     394,
     395,
     396,
     397,
     398,
     399,
     400,
     401,
     402,
     403,
     404,
     405,
     406,
     407,
     408,
     409,
     410,
     411,
     412,
     413,
     414,
     415,
     416,
     417,
     418,
     419,
     420,
     421,
     422,
     423,
     424,
     425,
     426,
     427,
     428,
     429,
     430,
     431,
     432,
     433,
     434,
     435,
     436,
     437,
     438,
     439,
     440,
     441,
     442,
     443,
     444,
     445,
     446,
     447,
     448,
     449,
     450,
     451,
     452,
     453,
     454,
     455,
     456,
     457,
     458,
     459,
     460,
     461,
     462,
     463,
     464,
     465,
     466,
     467,
     468,
     469,
     470,
     471,
     472,
     473,
     474,
     475,
     476,
     477,
     478,
     479,
     480,
     481,
     482,
     483,
     484,
     485,
     486,
     487,
     488,
     489,
     490,
     491,
     492,
     493,
     494,
     495,
     496,
     497,
     498,
     499,
     500,
     501,
     502,
     503,
     504,
     505,
     506,
     507,
     508,
     509,
     510,
     511,
     512,
     513,
     514,
     515,
     516,
     517,
     518,
     519,
     520,
     521,
     522,
     523,
     524,
     525,
     526,
     527,
     528,
     529,
     530,
     531,
     532,
     533,
     534,
     535,
     536,
     537,
     538,
     539,
     540,
     541,
     542,
     543,
     544,
     545,
     546,
     547,
     548,
     549,
     550,
     551,
     552,
     553,
     554,
     555,
     556,
     557,
     558,
     559,
     560,
     561,
     562,
     563,
     564,
     565,
     566,
     567,
     568,
     569,
     570,
     571,
     572,
     573,
     574,
     575,
     576,
     577,
     578,
     579,
     580,
     581,
     582,
     583,
     584,
     585,
     586,
     587,
     588,
     589,
     590,
     591,
     592,
     593,
     594,
     595,
     596,
     597,
     598,
     599,
     600,
     601,
     602,
     603,
     604,
     605,
     606,
     607,
     608,
     609,
     610,
     611,
     612,
     613,
     614,
     615,
     616,
     617,
     618,
     619,
     620,
     621,
     622,
     623,
     624,
     625,
     626,
     627,
     628,
     629,
     630,
     631,
     632,
     633,
     634,
     635,
     636,
     637,
     638,
     639,
     640,
     641,
     642,
     643,
     644,
     645,
     646,
     647,
     648,
     649,
     650,
     651,
     652,
     653,
     654,
     655,
     656,
     657,
     658,
     659,
     660,
     661,
     662,
     663,
     664,
     665,
     666,
     667,
     668,
     669,
     670,
     671,
     672,
     673,
     674,
     675,
     676,
     677,
     678,
     679,
     680,
     681,
     682,
     683,
     684,
     685,
     686,
     687,
     688,
     689,
     690,
     691,
     692,
     693,
     694,
     695,
     696,
     697,
     698,
     699,
     700,
     701,
     702,
     703,
     704,
     705,
     706,
     707,
     708,
     709,
     710,
     711,
     712,
     713,
     714,
     715,
     716,
     717,
     718,
     719,
     720,
     721,
     722,
     723,
     724,
     725,
     726,
     727,
     728,
     729,
     730,
     731,
     732,
     733,
     734,
     735,
     736,
     737,
     738,
     739,
     740,
     741,
     742,
     743,
     744,
     745,
     746,
     747,
     748,
     749,
     750,
     751,
     752,
     753,
     754,
     755,
     756,
     757,
     758,
     759,
     760,
     761,
     762,
     763,
     764,
     765,
     766,
     767,
     768,
     769,
     770,
     771,
     772,
     773,
     774,
     775,
     776,
     777,
     778,
     779,
     780,
     781,
     782,
     783,
     784,
     785,
     786,
     787,
     788,
     789,
     790,
     791,
     792,
     793,
     794,
     795,
     796,
     797,
     798,
     799,
     800,
     801,
     802,
     803,
     804,
     805,
     806,
     807,
     808,
     809,
     810,
     811,
     812,
     813,
     814,
     815,
     816,
     817,
     818,
     819,
     820,
     821,
     822,
     823,
     824,
     825,
     826,
     827,
     828,
     829,
     830,
     831,
     832,
     833,
     834,
     835,
     836,
     837,
     838,
     839,
     840,
     841,
     842,
     843,
     844,
     845,
     846,
     847,
     848,
     849,
     850,
     851,
     852,
     853,
     854,
     855,
     856,
     857,
     858,
     859,
     860,
     861,
     862,
     863,
     864,
     865,
     866,
     867,
     868,
     869,
     870,
     871,
     872,
     873,
     874,
     875,
     876,
     877,
     878,
     879,
     880,
     881,
     882,
     883,
     884,
     885,
     886,
     887,
     888,
     889,
     890,
     891,
     892,
     893,
     894,
     895,
     896,
     897,
     898,
     899,
     900,
     901,
     902,
     903,
     904,
     905,
     906,
     907,
     908,
     909,
     910,
     911,
     912,
     913,
     914,
     915,
     916,
     917,
     918,
     919,
     920,
     921,
     922,
     923,
     924,
     925,
     926,
     927,
     928,
     929,
     930,
     931,
     932,
     933,
     934,
     935,
     936,
     937,
     938,
     939,
     940,
     941,
     942,
     943,
     944,
     945,
     946,
     947,
     948,
     949,
     950,
     951,
     952,
     953,
     954,
     955,
     956,
     957,
     958,
     959,
     960,
     961,
     962,
     963,
     964,
     965,
     966,
     967,
     968,
     969,
     970,
     971,
     972,
     973,
     974,
     975,
     976,
     977,
     978,
     979,
     980,
     981,
     982,
     983,
     984,
     985,
     986,
     987,
     988,
     989,
     990,
     991,
     992,
     993,
     994,
     995,
     996,
     997,
     998,
     999]



## selection des données


```python
import pandas as pd 
df = pd.read_csv("C:/Users/User/Desktop/Ticanalyse/dataframe.csv")
df



```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>63.7.128.189</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>123.113.132.220</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>176.201.107.197</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>228.89.147.64</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>249.124.28.234</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>20.9.246.185</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>159.49.7.20</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 9 columns</p>
</div>




```python
## pour recuperer une colone
df["email"].head(10)
df.email.head(10) ## autrement 
```




    0    rmcswan0@cargocollective.com
    1              twyne1@walmart.com
    2           lyurkiewicz2@xrea.com
    3             tfri3@angelfire.com
    4               dlappine4@fc2.com
    5     pscalera5@cocolog-nifty.com
    6                jambage6@wix.com
    7              adymock7@umich.edu
    8            caldiss8@mozilla.com
    9           dredgewell9@umich.edu
    Name: email, dtype: object




```python
type(df)
```




    pandas.core.frame.DataFrame




```python
type(df.email)
```




    pandas.core.series.Series




```python
df[20:40]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>Burnaby</td>
      <td>Pound</td>
      <td>bpoundk@twitpic.com</td>
      <td>Male</td>
      <td>242.33.177.243</td>
      <td>Ukraine</td>
      <td>50258</td>
      <td>1984</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>Fair</td>
      <td>Batho</td>
      <td>fbathol@theglobeandmail.com</td>
      <td>Male</td>
      <td>179.234.85.255</td>
      <td>China</td>
      <td>10285</td>
      <td>1298</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>Irv</td>
      <td>Borless</td>
      <td>iborlessm@blogtalkradio.com</td>
      <td>Male</td>
      <td>226.75.128.49</td>
      <td>Russia</td>
      <td>94803</td>
      <td>785</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>Aubrette</td>
      <td>Alsop</td>
      <td>aalsopn@devhub.com</td>
      <td>Female</td>
      <td>19.93.81.156</td>
      <td>Russia</td>
      <td>60528</td>
      <td>203</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>Reed</td>
      <td>Covotti</td>
      <td>rcovottio@discovery.com</td>
      <td>Bigender</td>
      <td>190.70.234.166</td>
      <td>Russia</td>
      <td>11289</td>
      <td>155</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>Bronson</td>
      <td>Campbell-Dunlop</td>
      <td>bcampbelldunlopp@mtv.com</td>
      <td>Male</td>
      <td>61.20.119.228</td>
      <td>Indonesia</td>
      <td>96965</td>
      <td>1096</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>Olenka</td>
      <td>Moyler</td>
      <td>omoylerq@mapquest.com</td>
      <td>Female</td>
      <td>127.140.59.170</td>
      <td>South Africa</td>
      <td>70070</td>
      <td>1740</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>Cullie</td>
      <td>Hun</td>
      <td>chunr@uol.com.br</td>
      <td>Male</td>
      <td>72.224.176.128</td>
      <td>Philippines</td>
      <td>95234</td>
      <td>837</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>Zorana</td>
      <td>Cosham</td>
      <td>zcoshams@posterous.com</td>
      <td>Female</td>
      <td>15.84.44.149</td>
      <td>Poland</td>
      <td>9013</td>
      <td>983</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>Luisa</td>
      <td>Jillett</td>
      <td>ljillettt@umn.edu</td>
      <td>Female</td>
      <td>38.142.210.59</td>
      <td>Argentina</td>
      <td>38566</td>
      <td>1014</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31</td>
      <td>Vassili</td>
      <td>Wilhelmy</td>
      <td>vwilhelmyu@salon.com</td>
      <td>Male</td>
      <td>1.74.109.191</td>
      <td>Indonesia</td>
      <td>35810</td>
      <td>1288</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>Noby</td>
      <td>Kiessel</td>
      <td>nkiesselv@booking.com</td>
      <td>Male</td>
      <td>251.171.126.177</td>
      <td>Macedonia</td>
      <td>40928</td>
      <td>319</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>Benjamin</td>
      <td>Cristofvao</td>
      <td>bcristofvaow@mapy.cz</td>
      <td>Male</td>
      <td>127.90.199.104</td>
      <td>Colombia</td>
      <td>7196</td>
      <td>818</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>Lance</td>
      <td>Whayman</td>
      <td>lwhaymanx@wufoo.com</td>
      <td>Male</td>
      <td>17.138.139.26</td>
      <td>Philippines</td>
      <td>81244</td>
      <td>948</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>Alberto</td>
      <td>Sibly</td>
      <td>asiblyy@prnewswire.com</td>
      <td>Male</td>
      <td>74.100.153.49</td>
      <td>China</td>
      <td>58550</td>
      <td>416</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>Candida</td>
      <td>Le Sarr</td>
      <td>clesarrz@java.com</td>
      <td>Female</td>
      <td>21.250.134.34</td>
      <td>China</td>
      <td>5485</td>
      <td>1001</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>Angeline</td>
      <td>Hardson</td>
      <td>ahardson10@adobe.com</td>
      <td>Female</td>
      <td>23.157.211.119</td>
      <td>Armenia</td>
      <td>72310</td>
      <td>560</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>Danny</td>
      <td>Cardall</td>
      <td>dcardall11@tiny.cc</td>
      <td>Male</td>
      <td>20.246.168.138</td>
      <td>Indonesia</td>
      <td>87558</td>
      <td>211</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>Velvet</td>
      <td>Jertz</td>
      <td>vjertz12@redcross.org</td>
      <td>Female</td>
      <td>6.50.20.63</td>
      <td>Argentina</td>
      <td>28800</td>
      <td>1323</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>Blancha</td>
      <td>Rayer</td>
      <td>brayer13@alibaba.com</td>
      <td>Female</td>
      <td>79.201.140.57</td>
      <td>Morocco</td>
      <td>42363</td>
      <td>1076</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.loc[20:40]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>Burnaby</td>
      <td>Pound</td>
      <td>bpoundk@twitpic.com</td>
      <td>Male</td>
      <td>242.33.177.243</td>
      <td>Ukraine</td>
      <td>50258</td>
      <td>1984</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>Fair</td>
      <td>Batho</td>
      <td>fbathol@theglobeandmail.com</td>
      <td>Male</td>
      <td>179.234.85.255</td>
      <td>China</td>
      <td>10285</td>
      <td>1298</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>Irv</td>
      <td>Borless</td>
      <td>iborlessm@blogtalkradio.com</td>
      <td>Male</td>
      <td>226.75.128.49</td>
      <td>Russia</td>
      <td>94803</td>
      <td>785</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>Aubrette</td>
      <td>Alsop</td>
      <td>aalsopn@devhub.com</td>
      <td>Female</td>
      <td>19.93.81.156</td>
      <td>Russia</td>
      <td>60528</td>
      <td>203</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>Reed</td>
      <td>Covotti</td>
      <td>rcovottio@discovery.com</td>
      <td>Bigender</td>
      <td>190.70.234.166</td>
      <td>Russia</td>
      <td>11289</td>
      <td>155</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>Bronson</td>
      <td>Campbell-Dunlop</td>
      <td>bcampbelldunlopp@mtv.com</td>
      <td>Male</td>
      <td>61.20.119.228</td>
      <td>Indonesia</td>
      <td>96965</td>
      <td>1096</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>Olenka</td>
      <td>Moyler</td>
      <td>omoylerq@mapquest.com</td>
      <td>Female</td>
      <td>127.140.59.170</td>
      <td>South Africa</td>
      <td>70070</td>
      <td>1740</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>Cullie</td>
      <td>Hun</td>
      <td>chunr@uol.com.br</td>
      <td>Male</td>
      <td>72.224.176.128</td>
      <td>Philippines</td>
      <td>95234</td>
      <td>837</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>Zorana</td>
      <td>Cosham</td>
      <td>zcoshams@posterous.com</td>
      <td>Female</td>
      <td>15.84.44.149</td>
      <td>Poland</td>
      <td>9013</td>
      <td>983</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>Luisa</td>
      <td>Jillett</td>
      <td>ljillettt@umn.edu</td>
      <td>Female</td>
      <td>38.142.210.59</td>
      <td>Argentina</td>
      <td>38566</td>
      <td>1014</td>
    </tr>
    <tr>
      <th>30</th>
      <td>31</td>
      <td>Vassili</td>
      <td>Wilhelmy</td>
      <td>vwilhelmyu@salon.com</td>
      <td>Male</td>
      <td>1.74.109.191</td>
      <td>Indonesia</td>
      <td>35810</td>
      <td>1288</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>Noby</td>
      <td>Kiessel</td>
      <td>nkiesselv@booking.com</td>
      <td>Male</td>
      <td>251.171.126.177</td>
      <td>Macedonia</td>
      <td>40928</td>
      <td>319</td>
    </tr>
    <tr>
      <th>32</th>
      <td>33</td>
      <td>Benjamin</td>
      <td>Cristofvao</td>
      <td>bcristofvaow@mapy.cz</td>
      <td>Male</td>
      <td>127.90.199.104</td>
      <td>Colombia</td>
      <td>7196</td>
      <td>818</td>
    </tr>
    <tr>
      <th>33</th>
      <td>34</td>
      <td>Lance</td>
      <td>Whayman</td>
      <td>lwhaymanx@wufoo.com</td>
      <td>Male</td>
      <td>17.138.139.26</td>
      <td>Philippines</td>
      <td>81244</td>
      <td>948</td>
    </tr>
    <tr>
      <th>34</th>
      <td>35</td>
      <td>Alberto</td>
      <td>Sibly</td>
      <td>asiblyy@prnewswire.com</td>
      <td>Male</td>
      <td>74.100.153.49</td>
      <td>China</td>
      <td>58550</td>
      <td>416</td>
    </tr>
    <tr>
      <th>35</th>
      <td>36</td>
      <td>Candida</td>
      <td>Le Sarr</td>
      <td>clesarrz@java.com</td>
      <td>Female</td>
      <td>21.250.134.34</td>
      <td>China</td>
      <td>5485</td>
      <td>1001</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>Angeline</td>
      <td>Hardson</td>
      <td>ahardson10@adobe.com</td>
      <td>Female</td>
      <td>23.157.211.119</td>
      <td>Armenia</td>
      <td>72310</td>
      <td>560</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>Danny</td>
      <td>Cardall</td>
      <td>dcardall11@tiny.cc</td>
      <td>Male</td>
      <td>20.246.168.138</td>
      <td>Indonesia</td>
      <td>87558</td>
      <td>211</td>
    </tr>
    <tr>
      <th>38</th>
      <td>39</td>
      <td>Velvet</td>
      <td>Jertz</td>
      <td>vjertz12@redcross.org</td>
      <td>Female</td>
      <td>6.50.20.63</td>
      <td>Argentina</td>
      <td>28800</td>
      <td>1323</td>
    </tr>
    <tr>
      <th>39</th>
      <td>40</td>
      <td>Blancha</td>
      <td>Rayer</td>
      <td>brayer13@alibaba.com</td>
      <td>Female</td>
      <td>79.201.140.57</td>
      <td>Morocco</td>
      <td>42363</td>
      <td>1076</td>
    </tr>
    <tr>
      <th>40</th>
      <td>41</td>
      <td>Yance</td>
      <td>Pentercost</td>
      <td>ypentercost14@wix.com</td>
      <td>Male</td>
      <td>156.204.95.141</td>
      <td>Sweden</td>
      <td>80241</td>
      <td>814</td>
    </tr>
  </tbody>
</table>
</div>




```python
## pour charger l'index
df_email = df.set_index("email")
df_email.loc["nkiesselv@booking.com"]
```




    id                         32
    first_name               Noby
    last_name             Kiessel
    gender                   Male
    ip_address    251.171.126.177
    country             Macedonia
    price                   40928
    tax                       319
    Name: nkiesselv@booking.com, dtype: object




```python
## pour recuperer les valeurs de l'index email
df_email.loc["nkiesselv@booking.com"].values
```




    array([32, 'Noby', 'Kiessel', 'Male', '251.171.126.177', 'Macedonia',
           40928, 319], dtype=object)




```python
df_email.loc["nkiesselv@booking.com"].values.tolist()
```




    [32, 'Noby', 'Kiessel', 'Male', '251.171.126.177', 'Macedonia', 40928, 319]




```python
df_email.loc[["rmcswan0@cargocollective.com", "twyne1@walmart.com"]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
    <tr>
      <th>email</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>rmcswan0@cargocollective.com</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>twyne1@walmart.com</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
  </tbody>
</table>
</div>



## filtré les données 


```python
import pandas as pd 
df = pd.read_csv("C:/Users/User/Desktop/Ticanalyse/dataframe.csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>63.7.128.189</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>123.113.132.220</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>176.201.107.197</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>228.89.147.64</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>249.124.28.234</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>20.9.246.185</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>159.49.7.20</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 9 columns</p>
</div>




```python
##recupere la colone
df["gender"]=="Male"
```




    0       True
    1      False
    2      False
    3      False
    4      False
           ...  
    995     True
    996    False
    997     True
    998    False
    999     True
    Name: gender, Length: 1000, dtype: bool




```python
## le filtre une base de données 
df[df["gender"]=="Male"]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>Pennie</td>
      <td>Scalera</td>
      <td>pscalera5@cocolog-nifty.com</td>
      <td>Male</td>
      <td>32.128.34.13</td>
      <td>Afghanistan</td>
      <td>25101</td>
      <td>1126</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Alisander</td>
      <td>Dymock</td>
      <td>adymock7@umich.edu</td>
      <td>Male</td>
      <td>187.223.82.189</td>
      <td>China</td>
      <td>17988</td>
      <td>1652</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>Cheston</td>
      <td>Aldiss</td>
      <td>caldiss8@mozilla.com</td>
      <td>Male</td>
      <td>166.92.46.163</td>
      <td>Portugal</td>
      <td>30008</td>
      <td>1390</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>Sunny</td>
      <td>Watton</td>
      <td>swattona@msn.com</td>
      <td>Male</td>
      <td>189.217.177.56</td>
      <td>Sweden</td>
      <td>13511</td>
      <td>1497</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>990</th>
      <td>991</td>
      <td>Ax</td>
      <td>Armall</td>
      <td>aarmallri@state.tx.us</td>
      <td>Male</td>
      <td>232.216.27.190</td>
      <td>Indonesia</td>
      <td>48152</td>
      <td>854</td>
    </tr>
    <tr>
      <th>991</th>
      <td>992</td>
      <td>Rockey</td>
      <td>Towll</td>
      <td>rtowllrj@ucsd.edu</td>
      <td>Male</td>
      <td>163.136.56.20</td>
      <td>Brazil</td>
      <td>46814</td>
      <td>323</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>228.89.147.64</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>249.124.28.234</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>159.49.7.20</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>442 rows × 9 columns</p>
</div>




```python
## une autre manière de filtré
base_fille = df["gender"] == "Female"
df[base_fille]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>63.7.128.189</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>176.201.107.197</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>Jenifer</td>
      <td>Ambage</td>
      <td>jambage6@wix.com</td>
      <td>Female</td>
      <td>162.86.52.178</td>
      <td>Brazil</td>
      <td>35071</td>
      <td>1983</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Delphinia</td>
      <td>Redgewell</td>
      <td>dredgewell9@umich.edu</td>
      <td>Female</td>
      <td>14.95.78.189</td>
      <td>Japan</td>
      <td>26450</td>
      <td>538</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>987</th>
      <td>988</td>
      <td>Nadia</td>
      <td>Sackur</td>
      <td>nsackurrf@washington.edu</td>
      <td>Female</td>
      <td>232.34.141.23</td>
      <td>Canada</td>
      <td>84927</td>
      <td>1140</td>
    </tr>
    <tr>
      <th>988</th>
      <td>989</td>
      <td>Cristionna</td>
      <td>Dickenson</td>
      <td>cdickensonrg@google.ca</td>
      <td>Female</td>
      <td>209.86.82.18</td>
      <td>China</td>
      <td>48972</td>
      <td>542</td>
    </tr>
    <tr>
      <th>993</th>
      <td>994</td>
      <td>Hannie</td>
      <td>Bineham</td>
      <td>hbinehamrl@barnesandnoble.com</td>
      <td>Female</td>
      <td>132.202.151.79</td>
      <td>Bosnia and Herzegovina</td>
      <td>5621</td>
      <td>1056</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>20.9.246.185</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
  </tbody>
</table>
<p>452 rows × 9 columns</p>
</div>




```python
## pour voir si les valeur appartiennent 
df["country"].isin(["Canada", "Australia"])
```




    0      False
    1      False
    2      False
    3      False
    4      False
           ...  
    995    False
    996     True
    997    False
    998    False
    999    False
    Name: country, Length: 1000, dtype: bool




```python
base_pays = df["country"].isin(["Canada", "Australia"])
df[base_pays]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>69</th>
      <td>70</td>
      <td>Melony</td>
      <td>Sibly</td>
      <td>msibly1x@umich.edu</td>
      <td>Female</td>
      <td>173.193.15.197</td>
      <td>Canada</td>
      <td>7944</td>
      <td>1303</td>
    </tr>
    <tr>
      <th>75</th>
      <td>76</td>
      <td>Georgina</td>
      <td>Klaff</td>
      <td>gklaff23@ocn.ne.jp</td>
      <td>Bigender</td>
      <td>21.244.162.251</td>
      <td>Canada</td>
      <td>36596</td>
      <td>1828</td>
    </tr>
    <tr>
      <th>150</th>
      <td>151</td>
      <td>Maryanna</td>
      <td>Gaynes</td>
      <td>mgaynes46@studiopress.com</td>
      <td>Female</td>
      <td>177.145.38.199</td>
      <td>Canada</td>
      <td>56444</td>
      <td>1049</td>
    </tr>
    <tr>
      <th>187</th>
      <td>188</td>
      <td>Kele</td>
      <td>Brideoke</td>
      <td>kbrideoke57@google.cn</td>
      <td>Male</td>
      <td>70.71.67.70</td>
      <td>Canada</td>
      <td>38286</td>
      <td>1723</td>
    </tr>
    <tr>
      <th>189</th>
      <td>190</td>
      <td>Joanie</td>
      <td>Varney</td>
      <td>jvarney59@rediff.com</td>
      <td>Female</td>
      <td>236.233.66.64</td>
      <td>Canada</td>
      <td>42961</td>
      <td>1145</td>
    </tr>
    <tr>
      <th>252</th>
      <td>253</td>
      <td>Selie</td>
      <td>Byres</td>
      <td>sbyres70@businessweek.com</td>
      <td>Female</td>
      <td>153.74.110.139</td>
      <td>Canada</td>
      <td>25542</td>
      <td>316</td>
    </tr>
    <tr>
      <th>396</th>
      <td>397</td>
      <td>Blondy</td>
      <td>Beadnall</td>
      <td>bbeadnallb0@domainmarket.com</td>
      <td>Female</td>
      <td>109.227.197.70</td>
      <td>Canada</td>
      <td>11158</td>
      <td>702</td>
    </tr>
    <tr>
      <th>405</th>
      <td>406</td>
      <td>Amos</td>
      <td>Lidster</td>
      <td>alidsterb9@sohu.com</td>
      <td>Male</td>
      <td>36.11.148.221</td>
      <td>Canada</td>
      <td>54223</td>
      <td>1392</td>
    </tr>
    <tr>
      <th>553</th>
      <td>554</td>
      <td>Chauncey</td>
      <td>Swetenham</td>
      <td>cswetenhamfd@sogou.com</td>
      <td>Male</td>
      <td>222.39.50.90</td>
      <td>Canada</td>
      <td>37004</td>
      <td>1886</td>
    </tr>
    <tr>
      <th>564</th>
      <td>565</td>
      <td>Allegra</td>
      <td>Vinker</td>
      <td>avinkerfo@stanford.edu</td>
      <td>Genderfluid</td>
      <td>230.110.176.166</td>
      <td>Canada</td>
      <td>60911</td>
      <td>748</td>
    </tr>
    <tr>
      <th>621</th>
      <td>622</td>
      <td>Adriane</td>
      <td>Saterweyte</td>
      <td>asaterweyteh9@google.nl</td>
      <td>Female</td>
      <td>143.116.160.248</td>
      <td>Canada</td>
      <td>34127</td>
      <td>1304</td>
    </tr>
    <tr>
      <th>713</th>
      <td>714</td>
      <td>Sollie</td>
      <td>Killby</td>
      <td>skillbyjt@alexa.com</td>
      <td>Male</td>
      <td>102.154.109.202</td>
      <td>Canada</td>
      <td>3108</td>
      <td>980</td>
    </tr>
    <tr>
      <th>737</th>
      <td>738</td>
      <td>Rudie</td>
      <td>Brittin</td>
      <td>rbrittinkh@last.fm</td>
      <td>Male</td>
      <td>76.178.28.3</td>
      <td>Canada</td>
      <td>71238</td>
      <td>406</td>
    </tr>
    <tr>
      <th>790</th>
      <td>791</td>
      <td>Niels</td>
      <td>Lufkin</td>
      <td>nlufkinly@ameblo.jp</td>
      <td>Male</td>
      <td>6.200.16.86</td>
      <td>Canada</td>
      <td>47637</td>
      <td>939</td>
    </tr>
    <tr>
      <th>987</th>
      <td>988</td>
      <td>Nadia</td>
      <td>Sackur</td>
      <td>nsackurrf@washington.edu</td>
      <td>Female</td>
      <td>232.34.141.23</td>
      <td>Canada</td>
      <td>84927</td>
      <td>1140</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
  </tbody>
</table>
</div>




```python
# df_test=df.copy()
#df_test.price = df_test.price.apply(lambda x: x.replace("$", ""))
#df_test.price = df_test.price.astype(float)
#df_test[df_test["price"] >=5]

```

## suprimer une colone


```python
## pour suprimer une faut preciser l'axe et le rang
df.drop("ip_address", axis=1, inplace=True)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 8 columns</p>
</div>



## traiter les valeurs manquantes 


```python
## pour detecter les valeurs manquantes 
df.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>996</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>997</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>998</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>999</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 8 columns</p>
</div>




```python
df.notnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>3</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>4</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>996</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>997</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>998</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
    <tr>
      <th>999</th>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 8 columns</p>
</div>




```python
## cibler une colone pour voir les valeurs qui ne sont pas null
df["tax"].notnull()
```




    0      True
    1      True
    2      True
    3      True
    4      True
           ... 
    995    True
    996    True
    997    True
    998    True
    999    True
    Name: tax, Length: 1000, dtype: bool




```python
df[df["tax"].notnull()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 8 columns</p>
</div>




```python
## pour traiter 
df["tax".fillna(0)]
df["tax"].fillna(method="bfill") ## remplacer avec les valeurs autour
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    Cell In[314], line 2
          1 ## pour traiter 
    ----> 2 df["tax".fillna(0)]
          3 df["tax"].fillna(method="bfill")
    

    AttributeError: 'str' object has no attribute 'fillna'



```python
## pour suprimer toute les valeurs null 
df.dropna()
```


```python
# pour cibler les variables qui ont des valeurs manquantes 
df.dropna(subset=["nom de var"])
```


```python
df.dropna(subset=["nom de var"], inplace = True) ## pour appliquer avec inplace= True
```

## pour ajouter des colones 


## remplacer des valeurs 


```python
df["tax"].fillna(0),inplace=True
```


```python
import pandas as pd 
df = pd.read_csv("C:/Users/User/Desktop/Ticanalyse/dataframe.csv")
df
```


```python
## pour crer une variable et affecter la valeur zero
df["neveau"]=0
df
```


```python
del df["neveau"]
```


```python
df["price_total"] = df["price"] * (1-df["tax"]/100)
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
      <th>price_total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
      <td>-458433.54</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
      <td>-461689.20</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
      <td>-25367.16</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
      <td>-168988.98</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
      <td>-818188.89</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
      <td>-329804.64</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
      <td>-327103.14</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
      <td>-101047.60</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
      <td>-1587294.24</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
      <td>-1173523.51</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 9 columns</p>
</div>




```python
country = {"China": "ch", "New Caledonia": "nc", "Australia": "aus"}
df["pays"] = df["country"].map(country)
```


```python
df.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
      <th>price_total</th>
      <th>pays</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
      <td>-458433.54</td>
      <td>ch</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
      <td>-461689.20</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
      <td>-25367.16</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
      <td>-168988.98</td>
      <td>nc</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
      <td>-818188.89</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>Pennie</td>
      <td>Scalera</td>
      <td>pscalera5@cocolog-nifty.com</td>
      <td>Male</td>
      <td>Afghanistan</td>
      <td>25101</td>
      <td>1126</td>
      <td>-257536.26</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>Jenifer</td>
      <td>Ambage</td>
      <td>jambage6@wix.com</td>
      <td>Female</td>
      <td>Brazil</td>
      <td>35071</td>
      <td>1983</td>
      <td>-660386.93</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Alisander</td>
      <td>Dymock</td>
      <td>adymock7@umich.edu</td>
      <td>Male</td>
      <td>China</td>
      <td>17988</td>
      <td>1652</td>
      <td>-279173.76</td>
      <td>ch</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>Cheston</td>
      <td>Aldiss</td>
      <td>caldiss8@mozilla.com</td>
      <td>Male</td>
      <td>Portugal</td>
      <td>30008</td>
      <td>1390</td>
      <td>-387103.20</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Delphinia</td>
      <td>Redgewell</td>
      <td>dredgewell9@umich.edu</td>
      <td>Female</td>
      <td>Japan</td>
      <td>26450</td>
      <td>538</td>
      <td>-115851.00</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



## Analyse de données 


```python
import pandas as pd 
df = pd.read_csv("C:/Users/User/Desktop/Ticanalyse/dataframe.csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>country</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Ruprecht</td>
      <td>McSwan</td>
      <td>rmcswan0@cargocollective.com</td>
      <td>Male</td>
      <td>188.44.156.216</td>
      <td>China</td>
      <td>86334</td>
      <td>631</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Theo</td>
      <td>Wyne</td>
      <td>twyne1@walmart.com</td>
      <td>Female</td>
      <td>167.51.140.22</td>
      <td>Indonesia</td>
      <td>24428</td>
      <td>1990</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Lotte</td>
      <td>Yurkiewicz</td>
      <td>lyurkiewicz2@xrea.com</td>
      <td>Female</td>
      <td>63.7.128.189</td>
      <td>Indonesia</td>
      <td>4242</td>
      <td>698</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Terri</td>
      <td>Fri</td>
      <td>tfri3@angelfire.com</td>
      <td>Genderfluid</td>
      <td>123.113.132.220</td>
      <td>New Caledonia</td>
      <td>47737</td>
      <td>454</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Dalila</td>
      <td>Lappine</td>
      <td>dlappine4@fc2.com</td>
      <td>Female</td>
      <td>176.201.107.197</td>
      <td>Czech Republic</td>
      <td>62031</td>
      <td>1419</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Gray</td>
      <td>Goffe</td>
      <td>ggoffern@amazon.de</td>
      <td>Male</td>
      <td>228.89.147.64</td>
      <td>Netherlands</td>
      <td>41642</td>
      <td>892</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>Australia</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Kimball</td>
      <td>Fearne</td>
      <td>kfearnerp@behance.net</td>
      <td>Male</td>
      <td>249.124.28.234</td>
      <td>Argentina</td>
      <td>7192</td>
      <td>1505</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Lizzy</td>
      <td>Beswick</td>
      <td>lbeswickrq@topsy.com</td>
      <td>Female</td>
      <td>20.9.246.185</td>
      <td>United States</td>
      <td>85064</td>
      <td>1966</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Andrey</td>
      <td>Jacson</td>
      <td>ajacsonrr@vistaprint.com</td>
      <td>Male</td>
      <td>159.49.7.20</td>
      <td>Russia</td>
      <td>73483</td>
      <td>1697</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 9 columns</p>
</div>




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>price</th>
      <th>tax</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>500.500000</td>
      <td>51300.260000</td>
      <td>1034.126000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>288.819436</td>
      <td>28096.384104</td>
      <td>546.963475</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2080.000000</td>
      <td>107.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>250.750000</td>
      <td>26963.250000</td>
      <td>545.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>500.500000</td>
      <td>51281.500000</td>
      <td>1002.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>750.250000</td>
      <td>74548.250000</td>
      <td>1504.250000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1000.000000</td>
      <td>99963.000000</td>
      <td>2000.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df["price"].describe()
```




    count     1000.000000
    mean     51300.260000
    std      28096.384104
    min       2080.000000
    25%      26963.250000
    50%      51281.500000
    75%      74548.250000
    max      99963.000000
    Name: price, dtype: float64




```python
df["price"].mean()
```




    51300.26




```python
df["price"].sum()
```




    51300260




```python
df["price"].min()
```




    2080




```python
df["price"].max()
```




    99963




```python
## pour aficher les valeurs unique 
df["country"].unique().tolist()
```




    ['China',
     'Indonesia',
     'New Caledonia',
     'Czech Republic',
     'Afghanistan',
     'Brazil',
     'Portugal',
     'Japan',
     'Sweden',
     'Russia',
     'Peru',
     'Georgia',
     'Ukraine',
     'South Africa',
     'Philippines',
     'Poland',
     'Argentina',
     'Macedonia',
     'Colombia',
     'Armenia',
     'Morocco',
     'Uzbekistan',
     'United States',
     'Croatia',
     'Belarus',
     'Nicaragua',
     'France',
     'Luxembourg',
     'El Salvador',
     'Guatemala',
     'Canada',
     'Syria',
     'Vietnam',
     'Greece',
     'Netherlands',
     'Bangladesh',
     'Ireland',
     'Venezuela',
     'Lithuania',
     'Botswana',
     'Madagascar',
     'Slovenia',
     'Bosnia and Herzegovina',
     'Jordan',
     'Mexico',
     'Yemen',
     'Serbia',
     'Palestinian Territory',
     'Turkmenistan',
     'Cameroon',
     'Guinea',
     'Bahamas',
     'Sierra Leone',
     'Ecuador',
     'North Korea',
     'Spain',
     'Cuba',
     'Saint Martin',
     'Nigeria',
     'Mongolia',
     'Kazakhstan',
     'East Timor',
     'Iran',
     'Costa Rica',
     'Macao',
     'Kenya',
     'Moldova',
     'Iceland',
     'South Korea',
     'Sri Lanka',
     'Thailand',
     'Iraq',
     'Honduras',
     'Israel',
     'Democratic Republic of the Congo',
     'Azerbaijan',
     'Marshall Islands',
     'Estonia',
     'Uganda',
     'Belgium',
     'Central African Republic',
     'Germany',
     'Tanzania',
     'Maldives',
     'Pakistan',
     'Hong Kong',
     'Libya',
     'Kosovo',
     'Malaysia',
     'Tunisia',
     'Finland',
     'Zimbabwe',
     'Ghana',
     'Italy',
     'Denmark',
     'Belize',
     'Latvia',
     'Albania',
     'Paraguay',
     'Bulgaria',
     'Tuvalu',
     'Gabon',
     'Hungary',
     'Norway',
     'Benin',
     'New Zealand',
     'Cyprus',
     'Jamaica',
     'Austria',
     'Bermuda',
     'Egypt',
     'Ethiopia',
     'Zambia',
     'United Kingdom',
     'Rwanda',
     'Bolivia',
     'Sudan',
     'Mauritius',
     'Australia']




```python
df["country"].value_counts()
```




    country
    China           181
    Indonesia       106
    Russia           73
    Philippines      52
    Portugal         39
                   ... 
    Bahamas           1
    Tunisia           1
    Zimbabwe          1
    Turkmenistan      1
    Australia         1
    Name: count, Length: 119, dtype: int64




```python
df["gender"].value_counts()
```




    gender
    Female         452
    Male           442
    Genderqueer     22
    Bigender        21
    Non-binary      19
    Agender         19
    Polygender      13
    Genderfluid     12
    Name: count, dtype: int64




```python
df["gender"].value_counts(normalize=True) ## pour avoir en pourcentage 
```




    gender
    Female         0.452
    Male           0.442
    Genderqueer    0.022
    Bigender       0.021
    Non-binary     0.019
    Agender        0.019
    Polygender     0.013
    Genderfluid    0.012
    Name: proportion, dtype: float64




```python
## ca permet d'affichier la somme 
df.groupby("country").sum()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>first_name</th>
      <th>last_name</th>
      <th>email</th>
      <th>gender</th>
      <th>ip_address</th>
      <th>price</th>
      <th>tax</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Afghanistan</th>
      <td>1682</td>
      <td>PennieAlonsoIkeLonnie</td>
      <td>ScaleraYarrRudgerdLingner</td>
      <td>pscalera5@cocolog-nifty.comayarr6h@blog.comiru...</td>
      <td>MaleMaleMaleFemale</td>
      <td>32.128.34.1367.63.149.16254.179.134.138180.129...</td>
      <td>123522</td>
      <td>5207</td>
    </tr>
    <tr>
      <th>Albania</th>
      <td>1176</td>
      <td>TobieMareah</td>
      <td>FrangelloVan den Dael</td>
      <td>tfrangelloe4@symantec.commvandendaelii@woothem...</td>
      <td>MaleBigender</td>
      <td>247.254.66.142239.217.23.98</td>
      <td>119704</td>
      <td>2289</td>
    </tr>
    <tr>
      <th>Argentina</th>
      <td>12596</td>
      <td>LuisaVelvetDodyGayleneHarwilllEdgarManyaNikola...</td>
      <td>JillettJertzWetterEnnsNovichenkoSabenBelinWarc...</td>
      <td>ljillettt@umn.eduvjertz12@redcross.orgdwetter1...</td>
      <td>FemaleFemaleFemaleFemaleMaleMaleFemaleMaleFema...</td>
      <td>38.142.210.596.50.20.6356.168.213.151141.149.5...</td>
      <td>1412864</td>
      <td>22978</td>
    </tr>
    <tr>
      <th>Armenia</th>
      <td>3672</td>
      <td>AngelineFaeJoseeReneeSaundraEmile</td>
      <td>HardsonCreeberGarkenBreakwellNestleMcShee</td>
      <td>ahardson10@adobe.comfcreeber9n@themeforest.net...</td>
      <td>FemaleFemaleFemaleFemaleMaleMale</td>
      <td>23.157.211.119168.118.238.480.50.243.57252.79....</td>
      <td>362471</td>
      <td>4741</td>
    </tr>
    <tr>
      <th>Australia</th>
      <td>997</td>
      <td>Hollie</td>
      <td>Bosworth</td>
      <td>hbosworthro@weebly.com</td>
      <td>Female</td>
      <td>131.208.158.77</td>
      <td>18102</td>
      <td>1907</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>Venezuela</th>
      <td>1798</td>
      <td>KassieDenverSkippyLemmy</td>
      <td>MayberryKindreadGremainFalconar</td>
      <td>kmayberry38@spiegel.dedkindread4a@archive.orgs...</td>
      <td>FemaleMaleMaleMale</td>
      <td>183.153.193.194247.151.9.245152.229.116.223251...</td>
      <td>171608</td>
      <td>4985</td>
    </tr>
    <tr>
      <th>Vietnam</th>
      <td>3753</td>
      <td>DallisNoniDarDonnellHolly-anneEmanueleMarsiell...</td>
      <td>BallsCoochCowderoyStorreHardbattleMeasorKettri...</td>
      <td>dballs2a@miibeian.gov.cnncooch4e@mlb.comdcowde...</td>
      <td>MaleFemaleMaleMaleFemaleMaleFemaleMale</td>
      <td>135.11.19.13871.49.36.1819.133.15.8179.69.224....</td>
      <td>327758</td>
      <td>9126</td>
    </tr>
    <tr>
      <th>Yemen</th>
      <td>1266</td>
      <td>AltaHeinrickMichaelina</td>
      <td>CadaganFerroniGant</td>
      <td>acadagan3v@xing.comhferronicf@state.tx.usmgant...</td>
      <td>AgenderMaleFemale</td>
      <td>72.169.52.40114.7.174.30216.8.190.189</td>
      <td>172071</td>
      <td>2327</td>
    </tr>
    <tr>
      <th>Zambia</th>
      <td>819</td>
      <td>Trent</td>
      <td>Reford</td>
      <td>trefordmq@eepurl.com</td>
      <td>Male</td>
      <td>228.218.103.175</td>
      <td>70537</td>
      <td>1686</td>
    </tr>
    <tr>
      <th>Zimbabwe</th>
      <td>438</td>
      <td>Vasily</td>
      <td>Brumble</td>
      <td>vbrumblec5@instagram.com</td>
      <td>Male</td>
      <td>218.200.111.2</td>
      <td>25677</td>
      <td>1405</td>
    </tr>
  </tbody>
</table>
<p>119 rows × 8 columns</p>
</div>




```python
df.groupby("gender")["price"].sum()
```




    gender
    Agender         1093331
    Bigender        1007985
    Female         23134995
    Genderfluid      631459
    Genderqueer     1190199
    Male           22579670
    Non-binary       859378
    Polygender       803243
    Name: price, dtype: int64




```python
## comment afficher une courbe 
df.groupby("gender")["price"].sum().plot()
```




    <Axes: xlabel='gender'>




    
![png](output_69_1.png)
    



```python
df.groupby("gender")["price"].sum().plot.pie()
```




    <Axes: ylabel='price'>




    
![png](output_70_1.png)
    



```python
df.groupby("gender")["price"].sum().plot.pie(legend=True) ## pour la legende
```




    <Axes: ylabel='price'>




    
![png](output_71_1.png)
    



```python
df.groupby("gender")["price"].sum().plot.pie(rot=45, legend=True) ## pour agrandire 
```




    <Axes: ylabel='price'>




    
![png](output_72_1.png)
    



```python
df.groupby("country")["price"].sum().plot.bar(rot=45, figsize=[20,20], legend=True)
```




    <Axes: xlabel='country'>




    
![png](output_73_1.png)
    

